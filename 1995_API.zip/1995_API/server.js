const express = require('express');
const app = express();
const bodyParser = require('body-parser');

app.use(bodyParser.json());

const mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/1955_api');

var personSchema = new mongoose.Schema({
    name: {type: String, required: true},
}, {timestamps: true});

var Person = mongoose.model('Person', personSchema);

app.get('/', function(req,res) {
    Person.find({}, function(err, people) {
        if (err) {
            console.log('error exists', err);
            res.json({message: "Error", error: err})
        } else {
            res.json({message: "Success", data: people});
        }
    })
});

app.get('/new/:name', function(req,res) {
    var person = new Person({name: req.params.name});
    person.save(function(err) {
        if (err) {
            res.json({message: "Error", error: err});
        } else {
            res.json({message: "Success"});
        }
    })
});

app.get('/remove/:name', function(req, res) {
    Person.remove({name: req.params.name}, function(err) {
        if (err) {
            res.json({message: "Error", error: err});
        } else {
            res.json({messae: "Success"});
        }
    })
});

app.get('/:name', function(req,res) {
    Person.findOne({name: req.params.name}, function(err, person) {
        res.json({message: "Success", data: person});
    })
})

app.listen(8000, function() {
    console.log("listening to port 8000");
})