var express = require("express");
var app = express();
app.use(express.static(__dirname + "/static"));
app.set('views', __dirname + '/views');
app.set('view engine', 'ejs');
app.get('/cats', function(req, res) {
    res.render('index');
})
app.get('/cuddles', function(req,res) {
    var info_array = {food: "Spaghetti",
    age: 3, sleep_spot: ["under the bed", "in sunbeam"]};
    res.render('details', {img_url: "cat1.jpg", infos: info_array});
})
app.get('/pebbles', function(req, res) {
    var info_array = {food: "Sushi", 
    age: 5, sleep_spot: ["biking", "snowboarding"]};
    res.render('details', {img_url: "cat2.jpg", infos: info_array});
})
app.get('/paper', function(req, res) {
    var info_array = {food: "Cake", age: 6, sleep_spot: ["on the roof"]};
    res.render('details', {img_url: 'striped.jpg', infos: info_array})
})
app.listen(8000, function() {
    console.log("listening on port 8000");
})