var express = require('express');
var session = require('express-session');
var bodyParser = require('body-parser');
var app = express();
app.use(bodyParser.urlencoded({extended: true}));
app.use(session({
    secret:'keyboardkitteh',
    resave: false,
    saveUninitialized: true,
    cookie: { maxAge: 6000}
}))
app.set('views', __dirname + '/views');
app.set('view engine', 'ejs');
app.get('/', function(req,res) {
    if (req.session.counter) {
        req.session.counter = req.session.counter + 1;
    } else {
        req.session.counter = 1;
    }
    res.render('index', {real_count: req.session.counter});
})
app.post('/add_two', function(req,res) {
    req.session.counter += 1;
    res.redirect('/')
});
app.post('/reset', function(req,res) {
    req.session.counter = 0;
    res.redirect('/')
})
app.listen(5000, function() {
    console.log("listening on port 5000");
})