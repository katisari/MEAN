const express = require('express');
const app = express();
const bodyParser = require('body-parser');
const session = require('express-session');

app.use(session({
    secret: 'keyboardkitteh',
    resave: false,
    saveUninitialized: true,
    cookie: {maxAge: 6000}
}));

const flash = require('express-flash');
app.use(flash());
app.use(bodyParser.urlencoded({extended: true}));

app.use(express.static(__dirname + "/static"));
app.set('views', __dirname + "/views");
app.set('view engine', 'ejs');

const mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/basic_mongoose');
var animalSchema = new mongoose.Schema({
    title: {type: String, required: true},
    desc:  {type: String, required: true, minlength: 10}
}, {timestamps: true});
var Animal = mongoose.model('Animal', animalSchema);

app.get('/', function(req,res) {
    Animal.find({}, function(err,animals) {
        res.render('index', {all_animals: animals});
    });
});


app.get('/animal/new', function(req,res) {
    console.log("NEW EJS RENDERED");
    res.render('new_form');
});

app.get('/animal/:id', function(req,res) {
    Animal.findOne({_id: req.params.id}, function(err, animal) {
        res.render('details', {animal: animal});
    });
});

app.post('/animal', function(req,res) {
    var animal = new Animal({title: req.body.name, desc: req.body.desc});
    animal.save(function(err) {
        if (err) {
            for (var key in err.errors) {
                req.flash('new_animal', err.errors[key].message);
            }
            res.redirect('/animal/new');
        } else {
            console.log("successful");
            res.redirect('/');
        }
    })
});

app.get('/animal/edit/:id', function(req,res) {
    Animal.findOne({_id: req.params.id}, function(err, animal) {
        res.render('edit', {animal: animal, animal_id: req.params.id});
    });
});

app.post('/animal/:id', function(req,res) {
    Animal.findOne({_id: req.params.id}, function(err, animal) {
        animal.title = req.body.name;
        animal.desc = req.body.desc;
        animal.save(function(err) {
            if (err) {
                for (var key in err.errors) {
                    req.flash('new_animal', err.errors[key].message);
                }
                res.redirect('/animal/edit/' + req.params.id);
            } else {
                console.log("successful");
                res.redirect('/');
            }
        });
    });
});

app.get('/animal/destroy/:id', function(req,res) {
    Animal.remove({_id: req.params.id}, function(err) {
        res.redirect('/');
    });
})

app.listen(8000, function() {
    console.log("listening for port 8000");
});