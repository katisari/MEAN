var express = require('express');
var app = express();

app.use(express.static(__dirname + "/static"));
app.set('views', __dirname + '/views')
app.set('view engine', 'ejs');

app.get('/cars.html', function(req, res) {
    res.render('cars')
})
app.get('/cats.html', function(req, res) {
    res.render('cats')
})
app.get('/form.html', function(req, res) {
    res.render('form')
})

app.listen(8000, function() {
    console.log("listening on port 8000")
})