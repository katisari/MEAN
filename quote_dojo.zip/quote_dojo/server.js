const express = require('express');
const app = express();
const bodyParser = require('body-parser');
const session = require('express-session');
app.use(session({
    secret: 'keyboardkitteh',
    resave: false,
    saveUninitialized: true,
    cookie: {maxAge: 6000}
}));
const flash = require('express-flash');
app.use(flash());
app.use(bodyParser.urlencoded({extended: true}));

app.set('views', __dirname + "/views");
app.set('view engine', 'ejs');

const mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/basic_mongoose');
var quoteSchema = new mongoose.Schema({
    name: {type: String, required:true},
    text: {type:String, required: true, minlength: 10}
}, {timestamps: true});
mongoose.model('Quote', quoteSchema);
var Quote =mongoose.model('Quote');


app.get('/', function(req,res) {
    res.render('index');
});
app.post('/quotes', function(req,res) {
    var quote = new Quote({name: req.body.name, text: req.body.quote});
    quote.save(function(err) {
        if (err) {
            for(var key in err.errors) {
                req.flash('adding_quotes', err.errors[key].message);
            }
            res.redirect('/');
        } else {
            console.log("successful");
            res.redirect('/quotes');
        }
    });
});

app.get('/quotes', function(req,res) {
    Quote.find({}).sort('-createdAt').exec(function(err, quotes) {
        var date_passed = "";
        var date =  new Date(quotes[0].createdAt);
        // console.log(date.toDateString());
        res.render('quotes', {all_quotes: quotes});
    });
});

app.listen(8000, function() {
    console.log("listening for port 8000");
});