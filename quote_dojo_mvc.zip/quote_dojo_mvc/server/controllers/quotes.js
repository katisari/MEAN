const mongoose = require('mongoose');
var Quote = mongoose.model('Quote');


module.exports = {
    index: function(req,res) {
        res.render('index');
    },
    create: function(req,res) {
        var quote = new Quote({name: req.body.name, text: req.body.quote});
        quote.save(function(err) {
            if (err) {
                for(var key in err.errors) {
                    req.flash('adding_quotes', err.errors[key].message);
                }
                res.redirect('/');
            } else {
                console.log("successful");
                res.redirect('/quotes');
            }
        });
    },
    display_quotes: function(req, res) {
        Quote.find({}).sort('-createdAt').exec(function(err, quotes) {
            var date_passed = "";
            var date =  new Date(quotes[0].createdAt);
            // console.log(date.toDateString());
            res.render('quotes', {all_quotes: quotes});
        });
    }
}