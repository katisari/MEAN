
const mongoose = require('mongoose');


    var quoteSchema = new mongoose.Schema({
        name: {type: String, required:true},
        text: {type:String, required: true, minlength: 10}
    }, {timestamps: true});
    mongoose.model('Quote', quoteSchema);
    var Quote =mongoose.model('Quote');




