var express = require('express');
var app = express();
app.use(express.static(__dirname + "/static"));
const server = app.listen(8000);
const io = require('socket.io')(server);

app.set('views', __dirname + "/views");
app.set('view engine', 'ejs');
app.get('/', function(req,res) {
    res.render('index');
})
var counter = 0;
io.on('connection', function(socket) {
    socket.emit('greeting', counter);
    socket.on('epic_btn_pressed', function() {
        counter++;
        io.emit('update_num', counter);
        // socket.broadcast.emit('update_num', counter);
        // socket.emit('update_num', counter);
    });
    socket.on('reset_btn_pressed', function() {
        counter = 0;
        socket.broadcast.emit('update_num', counter);
        socket.emit('update_num', counter);
    });
})