const express = require('express');
const app = express();
const server = app.listen(8000);
const io = require('socket.io')(server);

app.set('views', __dirname + "/views");
app.set('view engine', 'ejs');

app.get('/', function(req,res) {
    res.render('index');
})
var color;

io.on('connection', function(socket) {
    socket.emit('greeting', color);

    socket.on('btn_pressed', function(data) {
        color = data;
        io.emit('update_color', color);
    })
})