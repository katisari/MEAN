var express = require('express');
var session = require('express-session');
var app = express();
var bodyParser = require('body-parser');
app.use(bodyParser.urlencoded({extended: true}));
app.use(session({
    secret: 'keyboardkitteh',
    resave: false,
    saveUninitialized: true,
    cookie: {maxAge: 6000}
}))
app.set('views', __dirname + '/views');
app.set('view engine', 'ejs');
app.get('/', function(req,res) {
    res.render('index');
})
app.get('/result', function(req,res) {
    res.render('result', {name: req.session.name, location: req.session.location, 
    language: req.session.language, comment: req.session.comment});
})
app.post('/process', function(req,res) {
    req.session.name = req.body.name;
    req.session.location = req.body.location;
    req.session.language = req.body.language;
    req.session.comment = req.body.comment;
    res.redirect('/result');
})
app.listen(5000, function() {
    console.log("listening to port 5000");
})